"""Read-only census counterexamples; not a production source-admission bypass."""
import base64
import copy
import gzip
import hashlib
import json
import os
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(os.environ.get("MEGATOKEN_REPO", "/workspace/scratch/dc03db3a26f3/megatoken"))
sys.path.insert(0, str(ROOT / "src"))
from megatoken.data.native_v8 import prepare_native_v8_training
from megatoken.data.schema import encode_episode
from megatoken.data.semantic_corpus_v8 import semantic_behaviors_v8
from megatoken.data.semantic_json import stable_algorithm_hash
from megatoken.generation.codec import ByteCodec

codec = ByteCodec.byte_fallback()
fixture = ROOT / "tests/fixtures/semantic-source-recovery-v8.json.gz.b64"
source = json.loads(gzip.decompress(base64.b64decode(fixture.read_bytes())))["cases"][0]["artifact"]

def prepare(document):
    prepared, _ = prepare_native_v8_training(document, codec=codec, max_positions=1024, max_history=128)
    annotations = json.loads(prepared.supervision.annotations_json)
    annotations["semantic_execution"]["publicArtifact"] = {key: document[key] for key in ("public", "contexts")}
    return replace(prepared, supervision=replace(prepared.supervision, annotations_json=json.dumps(annotations)))

def snapshot(episode):
    return {"behaviors": sorted(semantic_behaviors_v8(episode)),
            "eligibleTargetPositions": sum(sum(row.free_mask) for row in encode_episode(episode, codec))}

results = {}
original = prepare(source)
results["original"] = snapshot(original)
unscored = replace(original, records=tuple(replace(row, free_spans=()) if row.policy_mask else row for row in original.records))
try:
    results["emptyTargetFreeSpans"] = {"accepted": True, **snapshot(unscored)}
except ValueError as error:
    results["emptyTargetFreeSpans"] = {"accepted": False, "error": str(error)}

for name, change in (
    ("sourceReadDifferentBytes", lambda row: row["fields"].update(source="not the published program") if row["kind"] == "source-read" else None),
    ("nonexistentEvictionAndRead", lambda row: row["fields"].update(programId="unpublished", digest="0" * 64)),
):
    changed = copy.deepcopy(source)
    for row in changed["public"]["timeline"]:
        if row["kind"] in {"source-evict", "source-read"}:
            change(row)
    for context in changed["contexts"]:
        context["prefixDigest"] = stable_algorithm_hash(changed["public"]["timeline"][:context["visibleThrough"]])
    try:
        results[name] = {"accepted": True, **snapshot(prepare(changed))}
    except ValueError as error:
        results[name] = {"accepted": False, "error": str(error)}

print(json.dumps({"scope": "Actual native artifact replay, preparation, census and byte-codec masks; no live source/tokenizer admission claim", "sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT / "src/megatoken/data/native_v8.py", ROOT / "src/megatoken/data/semantic_corpus_v8.py", fixture]}, "cases": results}, indent=2))
