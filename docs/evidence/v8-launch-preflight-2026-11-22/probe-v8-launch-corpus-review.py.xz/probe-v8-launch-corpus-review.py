"""Read-only launch review with explicit fixture source/tokenizer injections.

This uses the launch regression's real preparation/replay/framing/split code.
It is not source qualification or production asset/readiness evidence.
"""
import hashlib
import importlib.abc
import json
import sys
import tempfile
from dataclasses import replace
from pathlib import Path

blocked = {
    "megatoken.data.semantic_corpus", "megatoken.data.semantic_contract",
    "megatoken.data.semantic_admission", "megatoken.data.witness_v6",
    "megatoken.data.semantic_harness_v6", "megatoken.training.semantic_budget",
    "megatoken.data.algorithm_v7", "megatoken.data.semantic_contract_v7",
    "megatoken.training.semantic_v7",
}

class NoLegacy(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in blocked:
            raise AssertionError("legacy wire import: " + fullname)

sys.meta_path.insert(0, NoLegacy())
from tests.test_semantic_launch_v8 import two_split_supply
from megatoken.data import PreparedCorpus
from megatoken.data.chunking import ChunkingConfig
from megatoken.data.dedup import DedupStore
from megatoken.data.storage import export_prepared
from megatoken.semantic_lineage_v8 import build_training_lineage_v8
from megatoken.training.semantic_launch_v8 import qualify_corpus_v8

repo = Path(__file__).parent / "megatoken"
reviewed = repo / "src/megatoken/training/semantic_launch_v8.py"
before = hashlib.sha256(reviewed.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix="v8-launch-review-", dir=Path(__file__).parent / "test-tmp") as temporary:
    root = Path(temporary)
    class Factory:
        def mktemp(self, name):
            path = root / name
            path.mkdir()
            return path
    _, _, config, codec, geometry, prepared = two_split_supply.__wrapped__(Factory())
    baseline = qualify_corpus_v8(config, codec, geometry)
    manifest = json.loads((prepared / "manifest.json").read_text())
    chunking = ChunkingConfig.from_identity(manifest["chunking"], codec)
    empty = root / "empty-prepared-root"
    store = DedupStore(root / "empty-dedup.sqlite")
    try:
        store.freeze()
        export_prepared(store, empty, codec=codec, source_receipts=[],
            pipeline_fingerprint="7" * 64, chunking=chunking)
    finally:
        store.close()
    config_with_empty = replace(config, datasets=[*config.datasets, str(empty)])
    try:
        extra = qualify_corpus_v8(config_with_empty, codec, geometry)
        outcome = {"status": "accepted", "trainingLineage": extra["trainingLineage"]}
    except Exception as error:
        outcome = {"status": "refused", "error": type(error).__name__, "reason": str(error)}
    # Same all_roots construction used by the ordinary trainer, without model
    # allocation or a learner. Empty roots still contribute to corpus identity.
    with PreparedCorpus(config_with_empty.datasets, split=None) as corpus:
        fingerprints = [json.loads((path / "manifest.json").read_text())["fingerprint"]
            for path in corpus.all_roots]
        ordinary_lineage = build_training_lineage_v8(
            policy=config.semantic_v8_policy, tokenizer_identity=codec.fingerprint,
            prepared_manifests=fingerprints, corpus_identity=corpus.identity,
            stream_identity=baseline["trainingLineage"]["streamDigest"],
            chunking=chunking.identity(codec))
        inventory = {"allRoots": len(corpus.all_roots), "nonemptyParts": len(corpus.parts),
            "manifestCountInTrainerLineage": len(ordinary_lineage["preparedManifestFingerprints"])}
    after = hashlib.sha256(reviewed.read_bytes()).hexdigest()
    assert before == after, "Launch helper changed during review"
    assert not blocked.intersection(sys.modules)
    print(json.dumps({"scope": "Pipeline audit fixture with explicit source/tokenizer authority injections; no production or optimizer claim",
        "reviewedSourceSha256": before, "blockedLegacyImports": sorted(blocked),
        "positiveCorpusGate": {"episodes": baseline["episodes"], "coverage": baseline["coverage"]},
        "extraEmptyRoot": outcome, "ordinaryTrainerLineage": {"status": "constructed", **inventory}}, indent=2))
