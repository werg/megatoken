# Independent V8 launch review

The ordinary producer worker repair is committed as `2d1d83d`. Its regression
selection passed 26 tests, including actual V8 source and module workers after
18 legacy clients were physically removed. This note concerns the subsequent
read-only review of the consumer launch changes; no consumer source was edited.

Both findings below have since been repaired by the owner. The exact retained
probes were rerun to separate `-after.json` outputs. The empty-root corpus is now
accepted with both manifest identities retained; the wrong-directory input is
now refused by the code gate before engineering qualification. Original failing
outputs remain unchanged.

## Reproduced findings

### Prepared-root inventory diverges from the ordinary trainer

`qualify_corpus_v8` collects manifest fingerprints from `corpus.parts`, which
contains only roots with episodes in the selected scope. `PreparedCorpus.identity`
and the ordinary trainer's lineage include `corpus.all_roots` instead.

The probe prepares the launch test's real two-split corpus and adds one valid
empty prepared root. The source/native row checks and both production split
checks succeed. Launch lineage construction then rejects the corpus with
`V8 training lineage identities or integrity differ`. Constructing lineage with
the trainer's `all_roots` inventory succeeds: two declared roots, one nonempty
part, two manifest fingerprints.

Use the same complete root inventory as the trainer, or make any intended
empty-root refusal explicit and consistent. The former preserves ordinary
trainer semantics.

Reproduction and initial result:

- `probe-v8-launch-corpus-review.py`
- `probe-v8-launch-corpus-review.json`
- Reviewed helper SHA-256:
  `c4392a169a22584b416105f3cb71aa050618fd7ae764450854ef341d1f4acfca`

The test fixture injects source and tokenizer audit authorities explicitly.
Real preparation, native replay/framing, split checks, and stream identities
are exercised. This is not production source qualification.

### The declared consumer checkout is not bound to the running package

The code and engineering gates read Git identities at caller-supplied paths.
They do not verify that the imported `megatoken` package belongs to the supplied
consumer checkout. The probe passes a real clean producer checkout at
`a494f007f7373fa4d96b76be88c5610fb815d6e8` under the supplied repository names and
uses those real revisions in the policy. Both gates pass while the running
consumer comes from a different, dirty checkout at
`0f572ebb76c67df28195aa46c5e8558f5b0a09ae`.

Missing assets keep the overall launch blocked, as expected. The reproduced
error is the successful code/engineering identity assertion, not a successful
production launch.

Require the resolved imported package to belong to the declared consumer source
checkout and verify that actual checkout's clean revision. This follows the
existing native-admission import-origin guard. Refusing duplicate supplied
repository roots would also catch the concrete wrong-directory input.

Reproduction and initial result:

- `probe-v8-launch-code-identity.py`
- `probe-v8-launch-code-identity.json`

## Checks that held

The fresh-process corpus probe blocked nine legacy semantic modules and still
qualified a real prepared train/validation pair through the new V8 corpus path.
The corpus gate checks every retained target with native replay/framing and
binds source, consumer, registry, tokenizer, and contract identities. Both
production splits and per-worker source supply are required. Window settings
are shared with the ordinary trainer.

Same-stage checkpoint lineage is compared with the freshly constructed supply.
Prior-stage coordinator bootstrap is treated as weights rather than an exact
continuation; the live coordinator must still bind the destination corpus and
stream. The destination lineage is correctly taken from the fresh corpus gate.

The local lightweight Python environment lacks PyTorch and safetensors. Full
model/checkpoint/coordinator execution branches were therefore not exercised
by this review. Asset-gate injections in the launch tests remain bounded test
evidence; no optimizer, model-quality, serving, or launch-readiness claim follows.

## Commands

From `/workspace/scratch/dc03db3a26f3/megatoken`, use the shared Python with:

```
export PYTHONPATH=/workspace/scratch/dc03db3a26f3/megatoken/src:/workspace/scratch/dc03db3a26f3/megatoken
/workspace/scratch/dc03db3a26f3/venv/bin/python /workspace/scratch/dc03db3a26f3/probe-v8-launch-corpus-review.py
/workspace/scratch/dc03db3a26f3/venv/bin/python /workspace/scratch/dc03db3a26f3/probe-v8-launch-code-identity.py
```

Retain the initial JSON results when repeating after repairs; write new results
to new paths.

## Repair verification

- `probe-v8-launch-corpus-review-after.json`: both train and validation checks
  pass; the additional empty root is accepted; launch lineage retains two
  manifests, matching the trainer's complete root inventory. The positive path
  still runs with all nine listed legacy modules blocked. Reviewed helper
  SHA-256 is `5d107b77371ac2777684632cf13f882ee456dbfeaf1bba2ad3a39f9b5fac54fc`.
- `probe-v8-launch-code-identity-after.json`: the exact prior input now fails
  with `Each repository requires its own distinct checkout`, and engineering
  qualification is blocked by that failed prerequisite. This exact probe
  exercises duplicate-root refusal. The owner's separate regression checks
  imported-package origin against distinct supplied roots.
