"""Reproduce launch's running-module/supplied-checkout identity gap.

Only real Git identities are used. Missing training assets intentionally keep
the overall launch blocked; this probes the code/engineering gates alone.
"""
import json
import tempfile
from pathlib import Path

import megatoken
from megatoken.training.semantic_launch import qualify_launch, repository_identity
from tests.test_semantic_launch_v8 import production_config

base = Path(__file__).parent
supplied = base / "verify-published"
identity = repository_identity(supplied)
assert identity["clean"]
policy = {"schema": "semantic-training-policy/8",
    "producerRevision": identity["revision"], "consumerRevision": identity["revision"],
    "registryDigest": "0" * 64}
with tempfile.TemporaryDirectory(prefix="v8-launch-code-review-", dir=base / "test-tmp") as temporary:
    root = Path(temporary)
    value, _ = production_config(root, policy)
    path = root / "launch.json"
    path.write_text(json.dumps(value))
    report = qualify_launch(path, repositories={name: supplied for name in (
        "tracing-js-self", "megatoken", "natlang")}, require_cuda=False)
    loaded_path = Path(megatoken.__file__).resolve()
    print(json.dumps({"scope": "Code/engineering gate probe only; missing real assets keep full launch blocked",
        "loadedConsumerModule": str(loaded_path),
        "loadedConsumerRepository": repository_identity(base / "megatoken"),
        "suppliedConsumerRepository": identity,
        "moduleInsideSuppliedCheckout": loaded_path.is_relative_to(supplied.resolve()),
        "codeRevisions": report["gates"]["codeRevisions"],
        "engineering": report["gates"]["engineering"],
        "preflightReady": report["preflightReady"],
        "optimizerSteps": report["optimizerSteps"]}, indent=2))
